package com.ciclo3.Grupo22;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Grupo22ApplicationTests {

	@Test
	void contextLoads() {
	}

}
